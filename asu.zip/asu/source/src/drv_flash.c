//
// Included Files
//
#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"

#include "drv_flash.h"
#include "Flash2833x_API_Library.h"
#include "port.h"

static FLASH_ST FlashStatus;
SHORT buffer[64];

Uint16 flash_status = 0x2EAD;

typedef struct {
     Uint16 *StartAddr;
     Uint16 *EndAddr;
} SECTOR;

SECTOR Sector[8] = {
         (Uint16 *)0x338000,(Uint16 *)0x33FFFF,
         (Uint16 *)0x330000,(Uint16 *)0x337FFF,
         (Uint16 *)0x328000,(Uint16 *)0x32FFFF,
         (Uint16 *)0x320000,(Uint16 *)0x327FFF,
         (Uint16 *)0x318000,(Uint16 *)0x31FFFF,
         (Uint16 *)0x310000,(Uint16 *)0x317FFF,
         (Uint16 *)0x308000,(Uint16 *)0x30FFFF,
         (Uint16 *)0x300000,(Uint16 *)0x307FFF
};

#pragma CODE_SECTION(flash_erase,  "ramfuncs");
#pragma CODE_SECTION(flash_write, "ramfuncs");

void flash_erase(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs)
{
    Uint16  state;

    DINT;

    EALLOW;
    Flash_CPUScaleFactor = SCALE_FACTOR;
    Flash_CallbackPtr = NULL;
    EDIS;

    state = Flash_Erase((SECTORH), &FlashStatus);
    if(state == STATUS_SUCCESS)
        {
        flash_status = 0x2EAD;
        }
    else
        {
        flash_status = FlashStatus.ExpectedData;
        }

    EINT;
}

void flash_write(UCHAR *pucRegBuffer, USHORT *paddr, USHORT usNRegs)
{
    FLASH_ST FlashStatus;
    int i;

    DINT;

    EALLOW;
    Flash_CPUScaleFactor = SCALE_FACTOR;
    Flash_CallbackPtr = NULL;
    EDIS;

    for(i=0; i<64; i++)
        {
        buffer[i] = (pucRegBuffer[i*2] << 8) | (pucRegBuffer[i*2+1]);
        }

    Flash_Program((Uint16 *)paddr, (Uint16 *)buffer, usNRegs, &FlashStatus);    // write SECTORH

    EINT;
}

void flash_read(UCHAR *pucRegBuffer, USHORT *paddr, USHORT usNRegs)
{
    Uint16  i;
    Uint16  buffer;

    for(i=0; i<usNRegs; i++)
        {
        buffer = *paddr;
        pucRegBuffer[i*2]   = (unsigned char)(buffer >> 8);
        pucRegBuffer[i*2+1] = (unsigned char)(buffer & 0xFF);
        paddr =  paddr+ 1;
        }
}
