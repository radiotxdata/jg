///////////////////////////////////////////////////////////////////////////////
// ASU
#include "drv_act_type.h"
#include "drv_sim.h"
#include "asu_config.h"

// xxyz: xx:project, y:actutor, z:version
#define  ACT_VERSION    0x0100

typedef unsigned int    Uint16;

///////////////////////////////////////////////////////////////////////////////
//#pragma CODE_SECTION(sim_main, ".flash_code");
//#pragma CODE_SECTION(sim_init, ".flash_code");

#if  STANDALONE_MODE
#pragma DATA_SECTION(gain, ".flash_data_arg");
#pragma DATA_SECTION(func, ".flash_data_fun");
#endif

const float gain[16] = {1.0, 2.0, 3.0, 4.0,
                        1.0, 2.0, 3.0, 4.0,
                        1.0, 2.0, 3.0, 4.0,
                        1.0, 2.0, 3.0, 4.0};
const unsigned long func[4] = {(unsigned long)sim_init, (unsigned long)sim_main, 3, 4};
///////////////////////////////////////////////////////////////////////////////

static struct ACTUATOR actuator[2];
static Uint16 act_version;


float limit_output(float fin, float fup, float fdown)
{
    if(fin > fup)
        {
        return fup;
        }
    else if(fin < fdown)
        {
        return fdown;
        }
    else
        {
        return fin;
        }
}

short float_to_da(float val)
{
    if(val > 7.0)
        val = 7.0;

    return (short)(val*65535/7.0);
}

float ad_to_float(short val)
{
    return (float)(val*10.0/32767);
}

static void sov_calc(short act)
{
    unsigned short usv;

    usv = (*(short *)SOV1_ADDR) & 0x00FF;      //1 SOV state

    if(usv & 1)
        actuator[act].sov1_on[0] = 1;
    else
        actuator[act].sov1_on[0] = 0;

    if(usv & 2)
        actuator[act].sov1_on[1] = 1;
    else
        actuator[act].sov1_on[1] = 0;

    if(usv & 4)
        actuator[act].sov1_on[2] = 1;
    else
        actuator[act].sov1_on[2] = 0;

    if(usv & 8)
        actuator[act].sov1_on[3] = 1;
    else
        actuator[act].sov1_on[3] = 0;

    usv = (*(short *)SOV2_ADDR) & 0x00FF;      // SOV state

    if(usv & 16)
        actuator[act].sov2_on[0] = 1;
    else
        actuator[act].sov2_on[0] = 0;

    if(usv & 32)
        actuator[act].sov2_on[1] = 1;
    else
        actuator[act].sov2_on[1] = 0;

    if(usv & 64)
        actuator[act].sov2_on[2] = 1;
    else
        actuator[act].sov2_on[2] = 0;

    if(usv & 128)
        actuator[act].sov2_on[3] = 1;
    else
        actuator[act].sov2_on[3] = 0;
}

static void ehv_cmd_calc(short act)
{
    actuator[act].ehv1_cmd = 0.0;
    actuator[act].ehv2_cmd = 0.0;
}

static void act_input(short act)
{
    short i;
    short sv;

    for(i=0; i<actuator[act].chan_num; i++)
        {
        actuator[act].stim_in[i] = *actuator[act].stim_ad[i];

        if(actuator[act].ehv1_valid)
            {
            sv = *actuator[act].ehv1_ad[i];
            actuator[act].ehv1_in[i] = sv;
            actuator[act].ehv1_val[i] = ad_to_float(sv);
            }

        if(actuator[act].ehv2_valid)
            {
            sv = *actuator[act].ehv2_ad[i];
            actuator[act].ehv2_in[i] = sv;
            actuator[act].ehv2_val[i] = ad_to_float(sv);
            }

        if(actuator[act].sov1_valid)
            {
            sv = *actuator[act].sov1_ad[i];
            actuator[act].sov1_in[i] = sv;
            actuator[act].sov1_val[i] = ad_to_float(sv);
            }

        if(actuator[act].sov2_valid)
            {
            sv = *actuator[act].sov2_ad[i];
            actuator[act].sov2_in[i] = sv;
            actuator[act].sov2_val[i] = ad_to_float(sv);
            }
        }
}

static void act_output(short act)
{
    int i;
    float fval;
    float ftemp;

    short ehv1_h;
    short ehv1_l;
    short ehv2_h;
    short ehv2_l;
    short ram_h;
    short ram_l;

    for(i=0; i<actuator[act].chan_num; i++)
        {
        fval = (actuator[act].ehv1_lvdt_sum[i] + actuator[act].ehv1_lvdt_out[i]) / 2;
        ehv1_h = float_to_da(fval);
        fval = (actuator[act].ehv1_lvdt_sum[i] - actuator[act].ehv1_lvdt_out[i]) / 2;
        ehv1_l = float_to_da(fval);

        fval = (actuator[act].ehv2_lvdt_sum[i] + actuator[act].ehv2_lvdt_out[i]) / 2;
        ehv2_h = float_to_da(fval);
        fval = (actuator[act].ehv2_lvdt_sum[i] - actuator[act].ehv2_lvdt_out[i]) / 2;
        ehv2_l = float_to_da(fval);

        ftemp = actuator[act].ram_lvdt_out[i] - actuator[act].ram_lvdt_offset[i];
        ftemp = ftemp * actuator[act].ram_lvdt_gain[i];
        fval = (actuator[act].ram_lvdt_sum[i] + ftemp) / 2;
        ram_h = float_to_da(fval);
        fval = (actuator[act].ram_lvdt_sum[i] - ftemp) / 2;
        ram_l = float_to_da(fval);

        if(actuator[act].ehv1_valid)
            {
            *(actuator[act].ehv1_da_h[i]) = ehv1_h;
            *(actuator[act].ehv1_da_l[i]) = ehv1_l;
            }

        if(actuator[act].ehv2_valid)
            {
            *(actuator[act].ehv2_da_h[i]) = ehv2_h;
            *(actuator[act].ehv2_da_l[i]) = ehv2_l;
            }

        *(actuator[act].ram_da_h[i]) = ram_h;
        *(actuator[act].ram_da_l[i]) = ram_l;
        }

    for(i=0; i<actuator[act].chan_num; i++)
        {
        actuator[act].sov_stat = 0;

        if(actuator[act].sov1_on[0])
            actuator[act].sov_stat = actuator[act].sov_stat | 1;

        if(actuator[act].sov1_on[1])
            actuator[act].sov_stat = actuator[act].sov_stat | 2;

        if(actuator[act].sov1_on[2])
            actuator[act].sov_stat = actuator[act].sov_stat | 4;

        if(actuator[act].sov1_on[3])
            actuator[act].sov_stat = actuator[act].sov_stat | 8;

        if(actuator[act].sov2_on[0])
            actuator[act].sov_stat = actuator[act].sov_stat | 16;

        if(actuator[act].sov2_on[1])
            actuator[act].sov_stat = actuator[act].sov_stat | 32;

        if(actuator[act].sov2_on[2])
            actuator[act].sov_stat = actuator[act].sov_stat | 64;

        if(actuator[act].sov2_on[3])
            actuator[act].sov_stat = actuator[act].sov_stat | 128;
        }
}

short sim_init(short in[], short out[])
{
    act_version = ACT_VERSION;

    actuator[0].chan_num = 4;
    actuator[0].ehv1_valid = 1;
    actuator[0].ehv2_valid = 0;
    actuator[0].sov1_valid = 0;
    actuator[0].sov2_valid = 0;

    actuator[0].stim_ad[0] = (short *)0x20000C;
    actuator[0].stim_ad[1] = (short *)0x20000D;
    actuator[0].stim_ad[2] = (short *)0x20000E;
    actuator[0].stim_ad[3] = (short *)0x20000F;

    actuator[0].ehv1_ad[0]   = (short *)0x210000;
    actuator[0].ehv1_ad[1]   = (short *)0x210001;
    actuator[0].ehv1_ad[2]   = (short *)0x210002;
    actuator[0].ehv1_ad[3]   = (short *)0x210003;
    actuator[0].ehv2_ad[0]   = (short *)0x210008;
    actuator[0].ehv2_ad[1]   = (short *)0x210009;
    actuator[0].ehv2_ad[2]   = (short *)0x21000A;
    actuator[0].ehv2_ad[3]   = (short *)0x21000B;
    actuator[0].sov1_ad[0]   = (short *)0x200000;
    actuator[0].sov1_ad[1]   = (short *)0x200001;
    actuator[0].sov1_ad[2]   = (short *)0x200002;
    actuator[0].sov1_ad[3]   = (short *)0x200003;
    actuator[0].sov2_ad[0]   = (short *)0x200000;
    actuator[0].sov2_ad[1]   = (short *)0x200001;
    actuator[0].sov2_ad[2]   = (short *)0x200002;
    actuator[0].sov2_ad[3]   = (short *)0x200003;
    actuator[0].ehv1_da_h[0] = (short *)0x20000A;
    actuator[0].ehv1_da_l[0] = (short *)0x20000B;
    actuator[0].ehv1_da_h[1] = (short *)0x200012;
    actuator[0].ehv1_da_l[1] = (short *)0x200013;
    actuator[0].ehv1_da_h[2] = (short *)0x20001A;
    actuator[0].ehv1_da_l[2] = (short *)0x20001B;
    actuator[0].ehv1_da_h[3] = (short *)0x200016;
    actuator[0].ehv1_da_l[3] = (short *)0x200017;
    actuator[0].ehv2_da_h[0] = (short *)0x20000C;
    actuator[0].ehv2_da_l[0] = (short *)0x20000D;
    actuator[0].ehv2_da_h[1] = (short *)0x200014;
    actuator[0].ehv2_da_l[1] = (short *)0x200015;
    actuator[0].ehv2_da_h[2] = (short *)0x20001C;
    actuator[0].ehv2_da_l[2] = (short *)0x20001D;
    actuator[0].ehv2_da_h[3] = (short *)0x20001E;
    actuator[0].ehv2_da_l[3] = (short *)0x20001F;
    actuator[0].ram_da_h[0]  = (short *)0x200008;
    actuator[0].ram_da_l[0]  = (short *)0x200009;
    actuator[0].ram_da_h[1]  = (short *)0x200010;
    actuator[0].ram_da_l[1]  = (short *)0x200011;
    actuator[0].ram_da_h[2]  = (short *)0x200018;
    actuator[0].ram_da_l[2]  = (short *)0x200019;
    actuator[0].ram_da_h[3]  = (short *)0x20000E;
    actuator[0].ram_da_l[3]  = (short *)0x20000F;

    actuator[0].ehv1_lvdt_sum[0] = 9.0;
    actuator[0].ehv1_lvdt_sum[1] = 9.0;
    actuator[0].ehv1_lvdt_sum[2] = 9.0;
    actuator[0].ehv1_lvdt_sum[3] = 9.0;
    actuator[0].ehv1_lvdt_offset[0] = 0.0;
    actuator[0].ehv1_lvdt_offset[1] = 0.0;
    actuator[0].ehv1_lvdt_offset[2] = 0.0;
    actuator[0].ehv1_lvdt_offset[3] = 0.0;

    actuator[0].ehv2_lvdt_sum[0] = 9.0;
    actuator[0].ehv2_lvdt_sum[1] = 9.0;
    actuator[0].ehv2_lvdt_sum[2] = 9.0;
    actuator[0].ehv2_lvdt_sum[3] = 9.0;
    actuator[0].ehv2_lvdt_offset[0] = 0.0;
    actuator[0].ehv2_lvdt_offset[1] = 0.0;
    actuator[0].ehv2_lvdt_offset[2] = 0.0;
    actuator[0].ehv2_lvdt_offset[3] = 0.0;

    actuator[0].ram_lvdt_sum[0] = 7.6;
    actuator[0].ram_lvdt_sum[1] = 7.6;
    actuator[0].ram_lvdt_sum[2] = 7.6;
    actuator[0].ram_lvdt_sum[3] = 7.6;
    actuator[0].ram_lvdt_offset[0] = 0.0;
    actuator[0].ram_lvdt_offset[1] = 0.0;
    actuator[0].ram_lvdt_offset[2] = 0.0;
    actuator[0].ram_lvdt_offset[3] = 0.0;
    actuator[0].ram_lvdt_gain[0] = 1.0;
    actuator[0].ram_lvdt_gain[1] = 1.0;
    actuator[0].ram_lvdt_gain[2] = 1.0;
    actuator[0].ram_lvdt_gain[3] = 1.0;

    actuator[0].sov1_on[0] = 0;
    actuator[0].sov1_on[1] = 0;
    actuator[0].sov1_on[2] = 0;
    actuator[0].sov1_on[3] = 0;

    actuator[0].sov2_on[0] = 0;
    actuator[0].sov2_on[1] = 0;
    actuator[0].sov2_on[2] = 0;
    actuator[0].sov2_on[3] = 0;

    act_output(0);
    //act_output(1);

    return 0;
}

short sim_main(short rin[], short rout[])
{
    Uint16 act_force;
    Uint16 sov_force;


    act_force = rin[0] & 1;
    sov_force = rin[0] & 2;

    //uisov = *(actuator[0].sov_di) & 0x00FF;      // SOV state

    act_input(0);
    //act_input(1);

    sov_calc(0);
    //sov_calc(1);

    if(sov_force)
        {
        actuator[0].sov1_on[0] = 1;
        actuator[0].sov1_on[1] = 1;
        actuator[0].sov1_on[2] = 1;
        actuator[0].sov1_on[3] = 1;

        actuator[0].sov2_on[0] = 1;
        actuator[0].sov2_on[1] = 1;
        actuator[0].sov2_on[2] = 1;
        actuator[0].sov2_on[3] = 1;
        }

    if(act_force)
        {
        actuator[0].ehv1_lvdt_out[0]  = (float)rin[1]*7.0/4096.0;
        actuator[0].ehv1_lvdt_out[1]  = (float)rin[2]*7.0/4096.0;
        actuator[0].ehv1_lvdt_out[2]  = (float)rin[3]*7.0/4096.0;
        actuator[0].ehv1_lvdt_out[3]  = (float)rin[4]*7.0/4096.0;

        actuator[0].ehv2_lvdt_out[0]  = (float)rin[5]*7.0/4096.0;
        actuator[0].ehv2_lvdt_out[1]  = (float)rin[6]*7.0/4096.0;
        actuator[0].ehv2_lvdt_out[2]  = (float)rin[7]*7.0/4096.0;
        actuator[0].ehv2_lvdt_out[3]  = (float)rin[8]*7.0/4096.0;

        actuator[0].ram_lvdt_out[0]  = (float)rin[9]*7.0/4096.0;
        actuator[0].ram_lvdt_out[1]  = (float)rin[10]*7.0/4096.0;
        actuator[0].ram_lvdt_out[2]  = (float)rin[11]*7.0/4096.0;
        actuator[0].ram_lvdt_out[3]  = (float)rin[12]*7.0/4096.0;
        }
    else
        {
        ehv_cmd_calc(0);
        //ehv_cmd_calc(1);

        actuator[0].ehv1_lvdt_out[0] = actuator[0].ehv1_cmd;
        actuator[0].ehv1_lvdt_out[1] = actuator[0].ehv1_cmd;
        actuator[0].ehv1_lvdt_out[2] = actuator[0].ehv1_cmd;
        actuator[0].ehv1_lvdt_out[3] = actuator[0].ehv1_cmd;

        actuator[0].ehv2_lvdt_out[0] = actuator[0].ehv2_cmd;
        actuator[0].ehv2_lvdt_out[1] = actuator[0].ehv2_cmd;
        actuator[0].ehv2_lvdt_out[2] = actuator[0].ehv2_cmd;
        actuator[0].ehv2_lvdt_out[3] = actuator[0].ehv2_cmd;

        actuator[0].ram_lvdt_out[0] = actuator[0].ehv1_cmd + actuator[0].ehv2_cmd + 0.5;
        actuator[0].ram_lvdt_out[1] = actuator[0].ehv1_cmd + actuator[0].ehv2_cmd + 0.5;
        actuator[0].ram_lvdt_out[2] = actuator[0].ehv1_cmd + actuator[0].ehv2_cmd + 0.5;
        actuator[0].ram_lvdt_out[3] = actuator[0].ehv1_cmd + actuator[0].ehv2_cmd + 0.5;
        }

    ///////////////////////////////////////////////////////////////////////////
    // output to modbus
    rout[4] = act_version;

    rout[6] = actuator[0].sov_stat;
    rout[7] = actuator[0].ram_lvdt_out[0] * 4096 / 7;
    rout[8] = actuator[0].ehv1_lvdt_out[0] * 4096 / 7;
    rout[9] = actuator[0].ehv2_lvdt_out[0] * 4096 / 7;

    rout[10] = actuator[0].stim_in[0];
    rout[11] = actuator[0].stim_in[1];
    rout[12] = actuator[0].stim_in[2];
    rout[13] = actuator[0].stim_in[3];

    rout[14] = actuator[0].ehv1_in[0];
    rout[15] = actuator[0].ehv1_in[1];
    rout[16] = actuator[0].ehv1_in[2];
    rout[17] = actuator[0].ehv1_in[3];

    rout[18] = actuator[0].ehv2_in[0];
    rout[19] = actuator[0].ehv2_in[1];
    rout[20] = actuator[0].ehv2_in[2];
    rout[21] = actuator[0].ehv2_in[3];

    rout[22] = actuator[0].sov1_in[0];
    rout[23] = actuator[0].sov1_in[1];
    rout[24] = actuator[0].sov1_in[2];
    rout[25] = actuator[0].sov1_in[3];

    rout[26] = actuator[0].sov2_in[0];
    rout[27] = actuator[0].sov2_in[1];
    rout[28] = actuator[0].sov2_in[2];
    rout[29] = actuator[0].sov2_in[3];


    ///////////////////////////////////////////////////////////////////////////
    // output to DAC
    act_output(0);
    //act_output(1);

    return 1;
}
