
#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File

//#include "sys_defines.h"
#include "drv_xintf.h"

#define  FPGA_SIZE_16B			0x40000

#pragma DATA_SECTION(fram, "ZONE7DATA");

volatile Uint16 fram[FPGA_SIZE_16B];


void xintf_init_zone7(void)
{
    // Make sure the XINTF clock is enabled
    EALLOW;
    SysCtrlRegs.PCLKCR3.bit.XINTFENCLK = 1;
    EDIS;

    // Configure the GPIO for XINTF with a 16-bit data bus
    //InitXintf16Gpio();

    EALLOW;
    
    ////////////////////////////////////////////////////////////////////////////
    // configuration for All Zones
    // Timing for all zones based on XTIMCLK = SYSCLKOUT/2
    XintfRegs.XINTCNF2.bit.XTIMCLK = 1;
    
    // Buffer up to 3 writes
    XintfRegs.XINTCNF2.bit.WRBUFF = 0;
    XintfRegs.XINTCNF2.bit.WLEVEL = 0;
    
    // XCLKOUT is enabled
    XintfRegs.XINTCNF2.bit.CLKOFF = 1;
    
    // XCLKOUT = XTIMCLK
    XintfRegs.XINTCNF2.bit.CLKMODE = 0;
    
    // Disable XHOLD to prevent XINTF bus from going into high impedance state whenever TZ3 signal goes low. This occurs because TZ3 on GPIO14 is shared with HOLD of XINTF
    XintfRegs.XINTCNF2.bit.HOLD = 1;

    ////////////////////////////////////////////////////////////////////////////
    // configuration for Zone 7
    // not double all Zone read/write lead/active/trail timing
    XintfRegs.XTIMING7.bit.X2TIMING = 1;

    // Zone write timing. When using ready, ACTIVE must be 1 or greater. Lead must always be 1 or greater. 
    XintfRegs.XTIMING7.bit.XWRLEAD   = 3;				// 0 xtimclk, 3 is max    1
    XintfRegs.XTIMING7.bit.XWRACTIVE = 7;				// 5 xtimclk, 7 is max    4
    XintfRegs.XTIMING7.bit.XWRTRAIL  = 3;				// 1 xtimclk, 3 is max    1
    
    // Zone read timing
    XintfRegs.XTIMING7.bit.XRDLEAD   = 1;				// 1 xtimclk, 0 is invalid
    XintfRegs.XTIMING7.bit.XRDACTIVE = 6;
    XintfRegs.XTIMING7.bit.XRDTRAIL  = 2;

    // Zone will not sample XREADY signal
    XintfRegs.XTIMING7.bit.USEREADY = 0;
    XintfRegs.XTIMING7.bit.READYMODE = 0;

    // 1,1 = x16 data bus
    // 0,1 = x32 data bus
    XintfRegs.XTIMING7.bit.XSIZE = 3;


    EDIS;

    // Force a pipeline flush to ensure that the write to the last register configured occurs before returning.
    __asm(" RPT #7 || NOP");
}


