///////////////////////////////////////////////////////////////////////////////
// ASU
#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "drv_sim.h"
#include "drv_act_type.h"
#include "asu_config.h"

#define SW_VERSION      0x0100

extern int uart_rxed;       // portserial.c

interrupt void prvvMBTimerIRQHandler( void );
interrupt void prvvMBSerialRXIRQHandler( void );
interrupt void prvvMBSerialTXIRQHandler( void );

short mbus_regs[128];        // 0-31 is input, 32-
Uint16 run_state;

static unsigned short led_cnt;
static unsigned short led;
static Uint16 internal_mode;
static Uint16 cntr;
static Uint32 heart_beat;
static Uint16 hb_cnt;


interrupt void cpu_timer1_isr( void )
{
    short (* fp)(short a[], short b[]);

    hb_cnt = hb_cnt+1;
    if(hb_cnt > 200)
        {
        hb_cnt = 0;
        heart_beat = heart_beat + 1;

        mbus_regs[OUT_REGS_OFFSET+2] = heart_beat>>16;
        mbus_regs[OUT_REGS_OFFSET+3] = heart_beat;
        }

    led_cnt = led_cnt+1;
    if(led_cnt > 300)
        {
        led_cnt = 0;

        if(led)
            {
            led = 0;
            }
        else
            {
            led = 4;
            }

        *(unsigned short*)LED2_ADDR = led;
        }

    mbus_regs[OUT_REGS_OFFSET+1] =  run_state;

    if(internal_mode)
        {
        sim_main(&mbus_regs[0], &mbus_regs[OUT_REGS_OFFSET]);
        }
    else
        {
        switch(run_state)
            {
            case ST_BOOT:
                cntr = cntr+1;
                if(cntr<2000 && uart_rxed>=3)
                    {
                    run_state = ST_PROGRAM;
                    }
                else if(cntr > 2000)        // 2 seconds
                    {
                    run_state = ST_INIT;
                    }
                break;

            case ST_INIT:
                fp = (short (*)(short a[], short b[]))*((Uint32 *)0x300000);    // sim_init()
                if((unsigned long)fp != 0xFFFFFFFF)
                    {
                    fp((short *)0, (short *)0);
                    }

                run_state = ST_WORK;
                break;

            case ST_WORK:
                fp = (short (*)(short a[], short b[]))*((Uint32 *)0x300002);    // sim_main()
                if((unsigned long)fp != 0xFFFFFFFF)
                    {
                    fp(&mbus_regs[0], &mbus_regs[OUT_REGS_OFFSET]);
                    }
                break;

            case ST_PROGRAM:
                break;

            default:
                break;
            }
        }

    CpuTimer1Regs.TCR.bit.TIF = 1;  // enable timer1 interrupt
    CpuTimer1Regs.TCR.bit.TRB = 1;  // reload  PRD value
}

void act_init(void)
{
    run_state = ST_BOOT;
    cntr = 0;
    heart_beat = 0;
    hb_cnt = 0;

    mbus_regs[OUT_REGS_OFFSET] = SW_VERSION;
    internal_mode = INTERNAL_MODE;

    if(internal_mode)
        {
        run_state = ST_INTERNAL;

        sim_init(0, 0);
        }
}

void intr_init(void)
{
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;

    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;  // Timer0

    PieCtrlRegs.PIEIER9.bit.INTx3 = 1;  // SCIB RX
    PieCtrlRegs.PIEIER9.bit.INTx4 = 1;  // SCIB TX

    EALLOW;

    PieVectTable.SCIRXINTB = &prvvMBSerialRXIRQHandler;
    PieVectTable.SCITXINTB = &prvvMBSerialTXIRQHandler;
    PieVectTable.TINT0     = &prvvMBTimerIRQHandler;
    PieVectTable.XINT13    = &cpu_timer1_isr;

    EDIS;

    IER |= M_INT1|M_INT9|M_INT13;
}

