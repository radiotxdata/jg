#include "DSP2833x_Device.h"
#include "DSP2833x_Examples.h"

#include "mb.h"
#include "drv_gpio.h"
#include "drv_xintf.h"
#include "drv_flash.h"
#include "drv_sim.h"
#include "drv_isr.h"

extern Uint16 Flash28_API_LoadStart;
extern Uint16 Flash28_API_LoadEnd;
extern Uint16 Flash28_API_LoadSize;

extern Uint16 RamfuncsLoadSize;
void act_init(void);        // drv_isr.c
void modbus_init(void);     // drv_modbus.c


#define  RUN_IN_FLASH         0
#define  INTR_TIME            1000


void main(void)
{
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Step 1: Initialize System Control: PLL, WatchDog, enable Peripheral Clocks
    InitSysCtrl();

    // Define ADCCLK clock frequency ( less than or equal to 25 MHz )
    EALLOW;
    SysCtrlRegs.HISPCP.all = 3;
    EDIS;

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Step 2: Initialize GPIO
    InitGpio();         // all are gpio input with pullup
    gpio_init();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Step 3: Clear all interrupts and initialize PIE vector table, disable CPU interrupts
    DINT;

    // Initialize PIE control registers to their default state.
    InitPieCtrl();

    // Disable CPU interrupts and clear all CPU interrupt flags
    IER = 0x0000;
    IFR = 0x0000;


    // Initialize the PIE vector table with pointers to the shell Interrupt Service Routines (ISR).
    // This will populate the entire table, even if the interrupt is not used in this example.  This is useful for debug purposes.
    InitPieVectTable();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Step 4: Initialize all the Device Peripherals:
    // InitPeripherals();
    InitXintf16Gpio();
    InitCpuTimers();
    init_scib_gpio();
    //InitAdc();
    //init_adc();
    //AdcRegs.ADCTRL2.all = 0x2000;   //����Ϊ��������ģʽ

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Step 5: User specific code
#if RUN_IN_FLASH
    memcpy(&Flash28_API_RunStart, &Flash28_API_LoadStart, (Uint32)&Flash28_API_LoadSize);
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (Uint32)&RamfuncsLoadSize);       // MemCopy
    InitFlash();
#endif

     xintf_init_zone7();

     modbus_init();
     act_init();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Step 6: enable interrupts
    intr_init();
    EINT;

    ConfigCpuTimer(&CpuTimer1, 150, INTR_TIME);  // time=150/150Mhz*1000=1ms
    CpuTimer1Regs.TCR.bit.TSS = 0;

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Step 7: main loop
    for( ;; )
        {
        ( void )eMBPoll(  );
        }
}
