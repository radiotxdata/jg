
#include "DSP2833x_Device.h"
#include "mb.h"
#include "drv_flash.h"
#include "drv_sim.h"
#include "drv_act_type.h"
#include "asu_config.h"

#define REG_INPUT_START   1000
#define REG_INPUT_NREGS   4
#define REG_HOLDING_START 0
#define REG_HOLDING_NREGS 130

extern short mbus_regs[48];     // drv_isr.c
extern Uint16 run_state;        // drv_isr.c
extern int uart_rxed;           // portserial.c

static Uint16 addr_hi16 = 0;

void modbus_init(void)
{
    short bid = 10;

    uart_rxed = 0;

    #if RS485_COM
        bid = bid + (*((short *)RS485_SLV_ADDR) & 0x1F);
    #endif

    // Select either ASCII or RTU Mode
    if(eMBInit( MB_RTU, bid, 0, 38400, MB_PAR_EVEN )  != MB_ENOERR )
        {
        }
    // Enable the Modbus Protocol Stack.
    else if(eMBEnable( ) != MB_ENOERR)
        {
        }
}

void mbus_regs_read(unsigned short offset, unsigned char *pucRegBuffer, unsigned char usNRegs)
{
    Uint16  i;
    Uint16  uiv;

    for(i=0; i<usNRegs; i++)
        {
        uiv = (Uint16) mbus_regs[i+offset];

        pucRegBuffer[i*2]   = ( unsigned char )(uiv >> 8);
        pucRegBuffer[i*2+1] = ( unsigned char )(uiv & 0xFF);
        }
}

void mbus_regs_write(unsigned short offset,unsigned char *pucRegBuffer, unsigned char usNRegs)
{
    Uint16  i;

    for(i=0; i<usNRegs; i++)
        {
        mbus_regs[i] = (int16)((pucRegBuffer[i*2] << 8) | pucRegBuffer[i*2+1]);
        }
}

void read(UCHAR *pucRegBuffer, USHORT *paddr, USHORT usNRegs)
{
    USHORT ust;
    USHORT i;

    for(i=0; i<usNRegs; i++)
        {
        ust = *paddr;
        pucRegBuffer[i*2]   = (unsigned char)(ust >> 8);
        pucRegBuffer[i*2+1] = (unsigned char)(ust & 0xFF);
        paddr = (USHORT *)((ULONG)paddr + 1);
        }
}

void write(UCHAR *pucRegBuffer, USHORT *paddr, USHORT usNRegs)
{
    USHORT ust;
    USHORT i;

    for(i=0; i<usNRegs; i++)
        {
        ust = (pucRegBuffer[i*2] << 8) | pucRegBuffer[i*2+1];
        *paddr = ust;
        paddr = (USHORT *)((ULONG)paddr + 1);
        }
}

eMBErrorCode eMBRegHoldingCB( UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs, eMBRegisterMode eMode )
{
	eMBErrorCode    eStatus = MB_ENOERR;
	USHORT *paddr;

	Uint32 addr;

    addr = addr_hi16;
	addr = (addr<<16) | usAddress;
	paddr = (USHORT *)addr;

    switch(eMode)
        {
        case MB_REG_READ:
            if(addr < 48)
                {
                mbus_regs_read(usAddress, pucRegBuffer, usNRegs);
                }
            else if(addr>=0x300000 && addr<0x308000)
                {
                flash_read( pucRegBuffer, paddr,  usNRegs);
                }
            else
                {
                read(pucRegBuffer, paddr, usNRegs);
                }
            break;

        case MB_REG_WRITE:
            if(addr < 48)
                {
                mbus_regs_write(usAddress, pucRegBuffer, usNRegs);
                }
            else if(addr>=0x300000 && addr<0x308000)
                {
                flash_status = 0;
                flash_write(pucRegBuffer, paddr, usNRegs);
                flash_status = 0x2EAD;
                }
            else
                {
                write(pucRegBuffer, paddr, usNRegs);
                }

            break;

        default:
            break;
        }

    return eStatus;
}

eMBErrorCode eMBRegCoilsCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNCoils, eMBRegisterMode eMode)
{
    short aa[4];
    short bb[4];
    short (* fp)(short a[], short b[]);

    switch ( eMode )
        {
        case MB_REG_READ:
            break;

        case MB_REG_WRITE:
            if(usAddress == MBUS_COIL_CMD_RUN_STATE)
                {
                run_state = pucRegBuffer[0];
                }
            else if(usAddress == MBUS_COIL_CMD_ERASE)
                {
                flash_status = 0;
                flash_erase(0, 0, 0);
                }
            else if(usAddress == MBUS_COIL_CMD_ADDR_HI16)
                {
                addr_hi16 = (pucRegBuffer[1] << 8) | pucRegBuffer[0];
                }
            else if(usAddress == 3)
                {
                aa[0] = 1;
                aa[1] = 2;
                aa[2] = 3;
                aa[3] = 4;
                fp = (short (*)(short a[], short b[]))*((Uint32 *)0x300000);
                fp(aa, bb);
                }
            break;

        default:
            break;
        }

    return MB_ENOREG;
}

eMBErrorCode eMBRegInputCB( UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs )
{
    eMBErrorCode    eStatus = MB_ENOERR;

    if(usAddress == MBUS_INR_FLASH_STATE)
        {
        pucRegBuffer[0] = (unsigned char)(flash_status >> 8);
        pucRegBuffer[1] = (unsigned char)(flash_status & 0xFF);
        }
    else if(usAddress == MBUS_INR_ADDR_HI16)
        {
        pucRegBuffer[0] = (unsigned char)(addr_hi16 >> 8);
        pucRegBuffer[1] = (unsigned char)(addr_hi16 & 0xFF);
        }
    else if(usAddress == MBUS_INR_RUN_STATE)
        {
        pucRegBuffer[0] = (unsigned char)(run_state >> 8);
        pucRegBuffer[1] = (unsigned char)(run_state & 0xFF);
        }
    else
        {
        }

    return eStatus;
}

eMBErrorCode eMBRegDiscreteCB( UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNDiscrete )
{
	return MB_ENOREG;
}

