//
// Included Files
//
#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "drv_gpio.h"


void gpio_init(void)
{
    EALLOW;

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // set gpio mux
    GpioCtrlRegs.GPAMUX1.bit.GPIO0  = 0;		// nmi
    GpioCtrlRegs.GPAMUX1.bit.GPIO1  = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO2  = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO3  = 0;	// rs485_tx_en
    GpioCtrlRegs.GPAMUX1.bit.GPIO4  = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO5  = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO6  = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO7  = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO8  = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO9  = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 0;		// gpio-xhold
    GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 0;		// gpio-xholda

    GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO19 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO20 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO21 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO22 = 0;		// gpio-syn_tx
    GpioCtrlRegs.GPAMUX2.bit.GPIO23 = 0;		// gpio-syn_ty
    GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 0;		// gpio-syn_tz
    GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 0;		// gpio-syn_rx
    GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 0;		// gpio-syn_ry
    GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0;		// gpio-syn_rz
    GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;		// sciarx
    GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;		// sciatx
    GpioCtrlRegs.GPAMUX2.bit.GPIO30 = 1;		// xa18
    GpioCtrlRegs.GPAMUX2.bit.GPIO31 = 1;		// xa17

    GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 0;		// gpio-xint1
    GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 0;		// gpio-xint2
    GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 0;		// gpio-xready
    GpioCtrlRegs.GPBMUX1.bit.GPIO35 = 2;		// x_rw
    GpioCtrlRegs.GPBMUX1.bit.GPIO36 = 2;		// xzcs0
    GpioCtrlRegs.GPBMUX1.bit.GPIO37 = 2;		// xzcs7
    GpioCtrlRegs.GPBMUX1.bit.GPIO38 = 2;		// xwe0
    GpioCtrlRegs.GPBMUX1.bit.GPIO39 = 2;		// xa16
    GpioCtrlRegs.GPBMUX1.bit.GPIO40 = 2;		// xa0
    GpioCtrlRegs.GPBMUX1.bit.GPIO41 = 2;		// xa1
    GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 2;		// xa2
    GpioCtrlRegs.GPBMUX1.bit.GPIO43 = 2;		// xa3
    GpioCtrlRegs.GPBMUX1.bit.GPIO44 = 2;		// xa4
    GpioCtrlRegs.GPBMUX1.bit.GPIO45 = 2;		// xa5
    GpioCtrlRegs.GPBMUX1.bit.GPIO46 = 2;		// xa6
    GpioCtrlRegs.GPBMUX1.bit.GPIO47 = 2;		// xa7

    GpioCtrlRegs.GPBMUX2.bit.GPIO48 = 2;		// xd31
    GpioCtrlRegs.GPBMUX2.bit.GPIO49 = 2;		// xd30
    GpioCtrlRegs.GPBMUX2.bit.GPIO50 = 2;		// xd29
    GpioCtrlRegs.GPBMUX2.bit.GPIO51 = 2;		// xd28
    GpioCtrlRegs.GPBMUX2.bit.GPIO52 = 2;		// xd27
    GpioCtrlRegs.GPBMUX2.bit.GPIO53 = 2;		// xd26
    GpioCtrlRegs.GPBMUX2.bit.GPIO54 = 2;		// xd25
    GpioCtrlRegs.GPBMUX2.bit.GPIO55 = 2;		// xd24
    GpioCtrlRegs.GPBMUX2.bit.GPIO56 = 2;		// xd23
    GpioCtrlRegs.GPBMUX2.bit.GPIO57 = 2;		// xd22
    GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 2;		// xd21
    GpioCtrlRegs.GPBMUX2.bit.GPIO59 = 2;		// xd20
    GpioCtrlRegs.GPBMUX2.bit.GPIO60 = 2;		// xd19
    GpioCtrlRegs.GPBMUX2.bit.GPIO61 = 2;		// xd18
    GpioCtrlRegs.GPBMUX2.bit.GPIO62 = 2;		// xd17
    GpioCtrlRegs.GPBMUX2.bit.GPIO63 = 2;		// xd16

    GpioCtrlRegs.GPCMUX1.bit.GPIO64 = 2;		// xd15
    GpioCtrlRegs.GPCMUX1.bit.GPIO65 = 2;		// xd14
    GpioCtrlRegs.GPCMUX1.bit.GPIO66 = 2;		// xd13
    GpioCtrlRegs.GPCMUX1.bit.GPIO67 = 2;		// xd12
    GpioCtrlRegs.GPCMUX1.bit.GPIO68 = 2;		// xd11
    GpioCtrlRegs.GPCMUX1.bit.GPIO69 = 2;		// xd10
    GpioCtrlRegs.GPCMUX1.bit.GPIO70 = 2;		// xd9
    GpioCtrlRegs.GPCMUX1.bit.GPIO71 = 2;		// xd8
    GpioCtrlRegs.GPCMUX1.bit.GPIO72 = 2;		// xd7
    GpioCtrlRegs.GPCMUX1.bit.GPIO73 = 2;		// xd6
    GpioCtrlRegs.GPCMUX1.bit.GPIO74 = 2;		// xd5
    GpioCtrlRegs.GPCMUX1.bit.GPIO75 = 2;		// xd4
    GpioCtrlRegs.GPCMUX1.bit.GPIO76 = 2;		// xd3
    GpioCtrlRegs.GPCMUX1.bit.GPIO77 = 2;		// xd2
    GpioCtrlRegs.GPCMUX1.bit.GPIO78 = 2;		// xd1
    GpioCtrlRegs.GPCMUX1.bit.GPIO79 = 2;		// xd0

    GpioCtrlRegs.GPCMUX2.bit.GPIO80 = 2;		// xa8
    GpioCtrlRegs.GPCMUX2.bit.GPIO81 = 2;		// xa9
    GpioCtrlRegs.GPCMUX2.bit.GPIO82 = 2;		// xa10
    GpioCtrlRegs.GPCMUX2.bit.GPIO83 = 2;		// xa11
    GpioCtrlRegs.GPCMUX2.bit.GPIO84 = 2;		// xa12
    GpioCtrlRegs.GPCMUX2.bit.GPIO85 = 2;		// xa13
    GpioCtrlRegs.GPCMUX2.bit.GPIO86 = 2;		// xa14
    GpioCtrlRegs.GPCMUX2.bit.GPIO87 = 2;		// xa15

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // set gpio direction
    GpioCtrlRegs.GPADIR.bit.GPIO0  = 0;         // input, nmi
    GpioCtrlRegs.GPADIR.bit.GPIO1  = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO2  = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO3  = 1;			// output-rx485_tx-en
    GpioCtrlRegs.GPADIR.bit.GPIO4  = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO5  = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO6  = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO7  = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO8  = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO9  = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO10 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO11 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO12 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO13 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO14 = 0;			// input-xhold
    GpioCtrlRegs.GPADIR.bit.GPIO15 = 0;			// input-xholda
    GpioCtrlRegs.GPADIR.bit.GPIO16 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO17 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO18 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO19 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO20 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO21 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO22 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO23 = 0;			// input
    GpioCtrlRegs.GPADIR.bit.GPIO24 = 0;			// input

    GpioCtrlRegs.GPADIR.bit.GPIO25 = 0;			// input-syn_rx
    GpioCtrlRegs.GPADIR.bit.GPIO26 = 0;			// input-syn_ry
    GpioCtrlRegs.GPADIR.bit.GPIO27 = 0;			// input-syn_rz
    GpioCtrlRegs.GPADIR.bit.GPIO28 = 0;         // sciarx
    GpioCtrlRegs.GPADIR.bit.GPIO29 = 0;         // sciatx

    GpioCtrlRegs.GPBDIR.bit.GPIO32 = 0;			// input-xint1
    GpioCtrlRegs.GPBDIR.bit.GPIO33 = 0;			// input-xint2
    GpioCtrlRegs.GPBDIR.bit.GPIO34 = 0;			// input-xready

    EDIS;
}


void init_scib_gpio(void)
{
   EALLOW;

   GpioCtrlRegs.GPAPUD.bit.GPIO19 = 0;    // Enable pull-up for GPIO19 (SCIRXDB)
   GpioCtrlRegs.GPAPUD.bit.GPIO18 = 0;    // Enable pull-up for GPIO18 (SCITXDB)

   GpioCtrlRegs.GPAQSEL2.bit.GPIO19 = 3;  // Asynch input GPIO19 (SCIRXDB)

   GpioCtrlRegs.GPAMUX2.bit.GPIO19 = 2;   // Configure GPIO19 for SCIRXDB operation
   GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 2;   // Configure GPIO18 for SCITXDB operation

   EDIS;
}
