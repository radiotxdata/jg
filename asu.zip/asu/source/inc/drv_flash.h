#include "mb.h"
#include "Flash2833x_API_Library.h"

#ifndef __DRV_FLASH_H__
#define __DRV_FLASH_H__
#ifdef __cplusplus
extern "C" {
#endif

extern Uint16 flash_status;

void flash_read(UCHAR *pucRegBuffer, USHORT *paddr, USHORT usNRegs);
void flash_write(UCHAR *pucRegBuffer, USHORT *paddr, USHORT usNRegs);
void flash_erase(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs);


#ifdef __cplusplus
}
#endif
#endif

