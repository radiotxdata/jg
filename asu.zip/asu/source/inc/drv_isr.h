
#ifndef DRV_ISR_H
#define DRV_ISR_H

interrupt void cpu_timer1_isr( void );
void intr_init(void);

#endif
