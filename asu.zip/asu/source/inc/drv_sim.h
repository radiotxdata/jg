#ifndef DRV_SIM_H
#define DRV_SIM_H

short sim_init(short in[], short out[]);
short sim_main(short rin[], short rout[]);

#endif

