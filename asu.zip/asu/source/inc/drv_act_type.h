#ifndef DRV_ACT_TYPE_H
#define DRV_ACT_TYPE_H

struct ACTUATOR
{
    short chan_num;
    short ehv1_valid;
    short ehv2_valid;
    short sov1_valid;
    short sov2_valid;

    short *stim_ad[4];
    short *ehv1_ad[4];
    short *ehv2_ad[4];
    short *sov1_ad[4];
    short *sov2_ad[4];

    short *ehv1_da_h[4];
    short *ehv1_da_l[4];
    short *ehv2_da_h[4];
    short *ehv2_da_l[4];
    short *ram_da_h[4];
    short *ram_da_l[4];

    float ehv1_lvdt_sum[4];
    float ehv1_lvdt_offset[4];
    float ehv2_lvdt_sum[4];
    float ehv2_lvdt_offset[4];
    float ram_lvdt_sum[4];
    float ram_lvdt_offset[4];
    float ram_lvdt_gain[4];

    short stim_in[4];
    short ehv1_in[4];
    short ehv2_in[4];
    short sov1_in[4];
    short sov2_in[4];

    float ehv1_val[4];
    float ehv2_val[4];
    float sov1_val[4];
    float sov2_val[4];

    short sov1_on[4];
    short sov2_on[4];

    short sov_stat;

    float ehv1_cmd;
    float ehv2_cmd;
    float ehv1_lvdt_out[4];
    float ehv2_lvdt_out[4];
    float ram_lvdt_out[4];
};

#endif

