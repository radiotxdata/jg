
#ifndef __DRV_XINTF_H__
#define __DRV_XINTF_H__
#ifdef __cplusplus
extern "C" {
#endif

extern volatile Uint16 fram[];

void xintf_init_zone7(void);


#ifdef __cplusplus
}
#endif
#endif

