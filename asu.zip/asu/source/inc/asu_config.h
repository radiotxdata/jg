
#ifndef ASU_CONFIG_H
#define ASU_CONFIG_H

#define  STANDALONE_MODE    0
#define  RS485_COM          1
#define  INTERNAL_MODE      1
#define  RS485_SLV_ADDR     0x200001
#define  LED2_ADDR          0x200038
#define  SOV1_ADDR          0x200002
#define  SOV2_ADDR          0x200003

#define  MBUS_COIL_CMD_RUN_STATE    0
#define  MBUS_COIL_CMD_ERASE		1
#define  MBUS_COIL_CMD_ADDR_HI16	2

#define  MBUS_INR_FLASH_STATE       1
#define  MBUS_INR_ADDR_HI16         2
#define  MBUS_INR_RUN_STATE         3

#define  ST_BOOT        0
#define  ST_INIT        1
#define  ST_WORK        2
#define  ST_INTERNAL    3
#define  ST_PROGRAM     4

#define  OUT_REGS_OFFSET          32
#define  OUT_REGS_ACT1_OFFSET     32
#define  OUT_REGS_ACT1_LEN        30
#define  OUT_REGS_ACT2_OFFSET     62
#define  OUT_REGS_ACT2_LEN        30

#define  IN_REGS_ACT1_OFFSET     0
#define  IN_REGS_ACT1_LEN        16
#define  IN_REGS_ACT2_OFFSET     16
#define  IN_REGS_ACT2_LEN        16

#endif
