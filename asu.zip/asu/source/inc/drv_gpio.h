
#ifndef __DRV_GPIO_H__
#define __DRV_GPIO_H__
#ifdef __cplusplus
extern "C" {
#endif


#define XHOLD_HI		GpioDataRegs.GPADAT.bit.GPIO14 = 1
#define XHOLD_LO		GpioDataRegs.GPADAT.bit.GPIO14 = 0
#define XHOLDA_HI		GpioDataRegs.GPADAT.bit.GPIO15 = 1
#define XHOLDA_LO		GpioDataRegs.GPADAT.bit.GPIO15 = 0

void gpio_init(void);
void init_scib_gpio(void);


#ifdef __cplusplus
}
#endif
#endif

