
/* ----------------------- Platform includes --------------------------------*/
#include "port.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "mb.h"
#include "mbport.h"

/* ----------------------- Defines ------------------------------------------*/
/* Timer ticks are counted in multiples of 50us. Therefore 20000 ticks are
 * one second.
 */
#define MB_TIMER_TICKS          ( 20000L )

/* ----------------------- Static variables ---------------------------------*/


/* ----------------------- Start implementation -----------------------------*/
BOOL xMBPortTimersInit( USHORT usTim1Timeout50us )
{
	InitCpuTimers();
	ConfigCpuTimer(&CpuTimer0, 150, 50*usTim1Timeout50us);  // 150/150000000*50=50us,timer=50us*usTim1Timeout50us

	CpuTimer0Regs.TCR.bit.TSS = 0;  // start timer0

	return TRUE;
}

void vMBPortTimersEnable( void )
{
	/* Reset timer counter and set compare interrupt. */
    CpuTimer0Regs.TCR.bit.TSS=1;    // stop timer0
    CpuTimer0Regs.TCR.bit.TRB=1;    // reload  PRD value
    CpuTimer0Regs.TCR.bit.TIE=1;    // enable timer0 interrupt
    CpuTimer0Regs.TCR.bit.TSS=0;    // start timer0
}

void vMBPortTimersDisable( void )
{

    CpuTimer0Regs.TCR.bit.TSS=1;
}


interrupt void prvvMBTimerIRQHandler( void )
{
	( void )pxMBPortCBTimerExpired(  );

	CpuTimer0Regs.TCR.bit.TIF = 1;  // enable timer0 interrupt
	CpuTimer0Regs.TCR.bit.TRB = 1;  // reload  PRD value

	PieCtrlRegs.PIEACK.all |= M_INT1;
}

