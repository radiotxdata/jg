
/* ----------------------- Platform includes --------------------------------*/
#include "port.h"
#include "DSP2833x_Examples.h"
#include "drv_act_type.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "mb.h"
#include "mbport.h"
#include "asu_config.h"

/* ----------------------- Defines ------------------------------------------*/
#define U0_CHAR                 ( 0x10 )        /* Data 0:7-bits / 1:8-bits */

#define DEBUG_PERFORMANCE       ( 1 )

#if DEBUG_PERFORMANCE == 1
#define DEBUG_PIN_RX            ( 0 )
#define DEBUG_PIN_TX            ( 1 )
#define DEBUG_PORT_DIR          ( P1DIR )
#define DEBUG_PORT_OUT          ( P1OUT )
#define DEBUG_INIT( )           \
  do \
  { \
    DEBUG_PORT_DIR |= ( 1 << DEBUG_PIN_RX ) | ( 1 << DEBUG_PIN_TX ); \
    DEBUG_PORT_OUT &= ~( ( 1 << DEBUG_PIN_RX ) | ( 1 << DEBUG_PIN_TX ) ); \
  } while( 0 );
#define DEBUG_TOGGLE_RX( ) DEBUG_PORT_OUT ^= ( 1 << DEBUG_PIN_RX )
#define DEBUG_TOGGLE_TX( ) DEBUG_PORT_OUT ^= ( 1 << DEBUG_PIN_TX )

#else

#define DEBUG_INIT( )
#define DEBUG_TOGGLE_RX( )
#define DEBUG_TOGGLE_TX( )
#endif

int uart_rxed;

#define  RS485_TX_EN		GpioDataRegs.GPADAT.bit.GPIO3

/* ----------------------- Static variables ---------------------------------*/
UCHAR           ucGIEWasEnabled = FALSE;
UCHAR           ucCriticalNesting = 0x00;

/* ----------------------- Start implementation -----------------------------*/
void vMBPortSerialEnable( BOOL xRxEnable, BOOL xTxEnable )
{
	ENTER_CRITICAL_SECTION(  );

	if(xRxEnable==TRUE)
	    {
	    ScibRegs.SCICTL1.bit.RXENA = 1; // enable SCI  receive

        #if RS485_COM
            while(ScibRegs.SCIFFTX.bit.TXFFST != 0);
            DELAY_US(100);

            RS485_TX_EN = 0;
        #endif
	    }
	else
	    {
	    ScibRegs.SCICTL1.bit.RXENA = 0;
	    }

	if(xTxEnable==TRUE)
	    {
	    ScibRegs.SCIFFTX.bit.TXFFIENA = 1;  // enable transmit FIFO interrupt
	    ScibRegs.SCICTL1.bit.TXENA    = 1;  // enable SCI transmit

        #if RS485_COM
                RS485_TX_EN = 1;
        #endif
	    }
	else
	    {
	    ScibRegs.SCIFFTX.bit.TXFFIENA = 0;
	    ScibRegs.SCICTL1.bit.TXENA    = 0;
	    }

    EXIT_CRITICAL_SECTION(  );
}

BOOL xMBPortSerialInit( UCHAR ucPort, ULONG ulBaudRate, UCHAR ucDataBits, eMBParity eParity )
{
    ScibRegs.SCICCR.all = 0x0007;   // 'N', 8, 1

    ScibRegs.SCICTL1.all = 0x0003;  // enable  SCI transmit,receive

    ScibRegs.SCICTL2.all = 0x0003;  // enable TXDAY,RXDAY interrupt

    ScibRegs.SCIHBAUD    = 0x0;     // 0x0=115200, 0x1=9600
    ScibRegs.SCILBAUD    = 0x0028;  // 0x28=115200, 0x79=38400, 0xE7=9600 baud @LSPCLK = 150MHz/4=37.5MHz.

    ScibRegs.SCIFFTX.all = 0xC008;  // SCI Reset,Enable SCI FIFO,leval bits 8
    ScibRegs.SCIFFRX.all = 0x0021;  // enable RX FIFO interrupt,leval bits 1
    ScibRegs.SCIFFCT.all = 0x00;

    ScibRegs.SCICTL1.all = 0x0023;  // SCI software reset
    ScibRegs.SCIFFTX.bit.TXFIFOXRESET = 1;  // re_enable tx FIFO
    ScibRegs.SCIFFRX.bit.RXFIFORESET  = 1;  // re_enable rx FIFO

	return 1;
}

BOOL xMBPortSerialPutByte( CHAR ucByte )
{
    while(ScibRegs.SCIFFTX.bit.TXFFST >= 16);

    ScibRegs.SCITXBUF=ucByte;

    return TRUE;
}

BOOL xMBPortSerialGetByte( CHAR *pucByte )
{
    if(ScibRegs.SCIFFRX.bit.RXFFST != 0)
        {
        *pucByte= ScibRegs.SCIRXBUF.all;
        return TRUE;
        }
    else
        return FALSE;
}

interrupt void prvvMBSerialRXIRQHandler( void )
{
    if(uart_rxed < 5)
        {
        uart_rxed++;
        }

	pxMBFrameCBByteReceived(  );

	ScibRegs.SCIFFRX.bit.RXFFOVRCLR = 1;    // clear RX FIFO overflow
	ScibRegs.SCIFFRX.bit.RXFFINTCLR = 1;    // clear RX FIFO intrrupt flag

    PieCtrlRegs.PIEACK.all |= M_INT9;

}

interrupt void prvvMBSerialTXIRQHandler( void )
{
	//DEBUG_TOGGLE_TX( );
	pxMBFrameCBTransmitterEmpty(  );

	ScibRegs.SCIFFTX.bit.TXFFINTCLR = 1;    // clear TX FIFO interrupt flag

    PieCtrlRegs.PIEACK.all |= M_INT9;
}

void EnterCriticalSection( void )
{
	DINT;

	ucCriticalNesting++;
}

void ExitCriticalSection( void )
{
	ucCriticalNesting--;
	//if( ucCriticalNesting == 0 )
		{
		//if( ucGIEWasEnabled )
			{
			EINT;
			}
		}
}
